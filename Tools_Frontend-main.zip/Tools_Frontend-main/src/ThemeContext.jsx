// ThemeContext.js
import { createContext } from 'react';

const ThemeContext = createContext('light'); // default value
export default ThemeContext;
